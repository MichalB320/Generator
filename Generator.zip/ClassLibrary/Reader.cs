﻿namespace ClassLibrary;

internal class Reader
{

    public Reader()
    {

    }

    public void Read(FileInfo csvFile)
    {
        //CSVData csv = new();

        //using (var sr = new StreamReader(csvFile.FullName))
        //{
        //    string? line;
        //    //line = sr.ReadLine();//Preskoc hlavicku
        //    while (!sr.EndOfStream)
        //    {
        //        line = sr.ReadLine();
        //        if (line is not null)
        //        {
        //            string[] casti = line.Split(';');


        //            List<string> riadok = new();
        //            foreach (var cast in casti)
        //            {
        //                riadok.Add(cast);
        //            }
        //            csv.AddRow(riadok);
        //        }
        //    }
        //}
    }
}
