﻿using ClassLibrary;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.DirectoryServices;
using System.Windows;
using System.Windows.Input;

namespace Generator.ViewModels;

internal class GenerateViewModel : ObservableObject
{
    private Mystructure _structure;
    public ICommand GenerateComman { get; set; }

    private string _output;
    public string Output { get => _output; set { _output = value; OnPropertyChanged(nameof(Output)); } }

    private string _input;
    public string Input { get => _input; set { _input = value; OnPropertyChanged(nameof(Input)); } }

    private string _csvKey;
    public string CsvKey
    {
        get => _csvKey;
        set
        {
            _csvKey = value;
            OnPropertyChanged(nameof(CsvKey));
        }
    }

    private string _ldapKey;
    public string LdapKey
    {
        get => _ldapKey;
        set
        {
            _ldapKey = value;
            OnPropertyChanged(nameof(LdapKey));
        }
    }

    private List<string> _zdroje;
    private ObservableCollection<ButtonViewModel> _buttons;
    private Generator.Models.Generator _gen;

    public GenerateViewModel(Mystructure structure, ObservableCollection<ButtonViewModel> buttons)
    {


        _zdroje = new();
        _buttons = buttons;

        GenerateComman = new RelayCommand(OnClickGenerate);

        _structure = structure;
        _csvKey = "skupina";
        _ldapKey = "physicalDeliveryOfficeName";

        //CSVData csv = structure.GetItem<CSVData>(0);

        //_output = $"{csv.Count}";


        //_input = "useradd -c \"$displayName$\" -d /home/$uid$ -u $uidNumber$ -m -g $gidNumber$ -s /bin/bash $uid$\nchmod 701 /home/$uid$";
        _input = "useradd -c \"$ukazka2.meno$\" -d /home/$ukazka4.meno$ -u $ukazka2.priezvisko$ -m -g $ukazka4.priezvisko$ -s /bin/bash $ukazka2.skupina$\nchmod 701 /home/$ukazka4.skupina$";

        _gen = new(_input, _structure, _buttons);
    }

    private void ShowFind()
    {
        var odpad = FindVariables(Input, Input.Count(c => c == '$'));

        List<ButtonViewModel> foundMach = _buttons.Where(ButtonViewModel => _zdroje.Contains(ButtonViewModel.Content)).ToList();

        foreach (var buttonViewModel in foundMach)
            MessageBox.Show($"nasiel som {buttonViewModel.Content}");


        //var index = _zdroje.IndexOf(foundMach[0].Content);
        int indexMatches = 0;
        foreach (var match in foundMach)
        {
            ButtonViewModel btn = null;

            foreach (var button in _buttons)
            {
                if (button.Content == foundMach[indexMatches].Content)
                {
                    btn = button;
                }
            }
            btn = _buttons.FirstOrDefault(BtnVM => BtnVM.Content == foundMach[indexMatches].Content);

            var index = _buttons.IndexOf(btn);
            Type typ = _buttons[index].Type;

            if (typ == typeof(CSVData))
            {
                var fromStructure = _structure.GetItem<CSVData>(index);

            }

            if (typ == typeof(SearchResultCollection))
            {
                var fromStructure = _structure.GetItem<SearchResultCollection>(index);
            }
            indexMatches++;
        }


        //foreach (ButtonViewModel buttonViewModel in _buttons)
        //{
        //    string match = buttonViewModel.Content;
        //    if (_zdroje.Contains(match)) 
        //    {
        //        MessageBox.Show($"nasiel som {match}");
        //    }
        //}
    }

    private void OnClickGenerate()
    {
        Generator.Models.Generator gen = new(Input, _structure, _buttons);


        gen.FindStrings();
        gen.FindSourcesAndVariables();
        gen.PrepareVariable();
        string output = gen.Generate();
        Output = output;
        //for (int i = 0; i < 10; i++)
        //{
        //    gen.GenerateLine(i);
        //}

        //ShowFind();
        //int count = Input.Count(c => c == '$');

        //if (count % 2 == 0)
        //{
        //    StringBuilder sb = new();
        //    int index = 0;
        //    foreach (var item in _structure.Iter())
        //    {
        //        List<string> vars = new();
        //        vars = FindVariables(Input, count);

        //        var csvFile = _structure.GetItem<object>(index);

        //        if (csvFile.GetType() == typeof(CSVData))
        //        {
        //            //CSV
        //            CSVData file = (CSVData)csvFile;
        //            List<string> variableValues = file.GetRow(0);
        //            for (int i = 1; i < file.Count; i++)
        //            {
        //                int startIndex1 = -1;
        //                for (int j = 0; j < count / 2; j++)
        //                {
        //                    int startIndex = startIndex1;
        //                    int endIndex = Input.IndexOf('$', startIndex + 1);
        //                    startIndex1 = Input.IndexOf('$', endIndex + 1);
        //                    string subStr = Input.Substring(startIndex + 1, endIndex - 1 - startIndex);
        //                    List<string> riadok = file.GetRow(i);
        //                    var extract = riadok[variableValues.IndexOf(vars[j])];
        //                    //output.Dispatcher.Invoke(() => output.AppendText($"{subStr}{extract}"));
        //                    sb.Append($"{subStr}{extract}");

        //                }
        //                sb.Append("\n\n");
        //                //output.Dispatcher.Invoke(() =>
        //                //{
        //                //    output.AppendText("\n");
        //                //    output.AppendText("\n");
        //                //});
        //            }
        //        }
        //        if (csvFile.GetType() == typeof(SearchResultCollection))
        //        {
        //            //LDAP
        //            foreach (SearchResult result in (SearchResultCollection)csvFile)
        //            {
        //                DirectoryEntry resultEntry = result.GetDirectoryEntry();

        //                int startIndex1 = -1;
        //                for (int i = 0; i < count / 2; i++)
        //                {
        //                    int startIndex = startIndex1;
        //                    int endIndex = Input.IndexOf('$', startIndex + 1);
        //                    startIndex1 = Input.IndexOf('$', endIndex + 1);
        //                    string subStr = Input.Substring(startIndex + 1, endIndex - 1 - startIndex);
        //                    //output.Dispatcher.Invoke(() => output.AppendText($"{subStr}{resultEntry.InvokeGet(vars[i])}"));
        //                    sb.Append($"{subStr}{resultEntry.InvokeGet(vars[i])}");
        //                }
        //                sb.Append("\n\n");
        //                //output.Dispatcher.Invoke(() =>
        //                //{
        //                //    output.AppendText("\n");
        //                //    output.AppendText("\n");
        //                //});
        //            }

        //        }
        //        index++;
        //    }
        //    Output = sb.ToString();
        //    //List<string> variableValues = csvFile.GetRow(0);

        //    //StringBuilder sb = new();

        //    //for (int i = 1; i < csvFile.Count; i++)
        //    //{
        //    //    int startIndex1 = -1;
        //    //    for (int j = 0; j < count / 2; j++)
        //    //    {
        //    //        int startIndex = startIndex1;
        //    //        int endIndex = Input.IndexOf('$', startIndex + 1);
        //    //        startIndex1 = Input.IndexOf('$', endIndex + 1);
        //    //        string subStr = Input.Substring(startIndex + 1, endIndex - 1 - startIndex);
        //    //        List<string> riadok = csvFile.GetRow(i);
        //    //        var extract = riadok[variableValues.IndexOf(vars[j])];
        //    //        //output.Dispatcher.Invoke(() => output.AppendText($"{subStr}{extract}"));
        //    //        sb.Append($"{subStr}{extract}");

        //    //    }
        //    //    sb.Append("\n\n");
        //    //    //output.Dispatcher.Invoke(() =>
        //    //    //{
        //    //    //    output.AppendText("\n");
        //    //    //    output.AppendText("\n");
        //    //    //});
        //    //}
        //    //Output = sb.ToString();
        //}
    }

    private List<string> FindVariables(string input, int count)
    {
        List<string> vars = new();
        int startI = input.IndexOf('$');

        for (int i = 0; i < count / 2; i++)
        {
            int startIndex = startI;
            int endIndex = input.IndexOf('$', startIndex + 1);
            startI = input.IndexOf('$', endIndex + 1);
            string subStr = input.Substring(startIndex + 1, endIndex - 1 - startIndex);
            vars.Add(subStr);
        }

        List<string> returnList = new();
        //List<string> zdroje = new();
        foreach (var var in vars)
        {
            var parts = var.Split('.');
            returnList.Add(parts[1]);

            if (!_zdroje.Contains(parts[0]))
                _zdroje.Add(parts[0]);
        }

        return returnList;
    }
}
