﻿using System.Windows;
using System.Windows.Controls;

namespace Generator.Views
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();
        }

        private void OnMoueseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            NextPage.Height = 50;
            NextPage.Width = 50;
            NextPage.Margin = new Thickness(5);
        }

        private void OnMouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            NextPage.Height = 60;
            NextPage.Width = 60;
            NextPage.Margin = new Thickness(0);
        }
    }
}
