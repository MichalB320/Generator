﻿using ClassLibrary;
using Generator.Models;
using Generator.ViewModels;
using System.Windows;

namespace Generator;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
    private Mystructure _list;
    private Manager _manager;

    public App()
    {
        _list = new Mystructure();
        _manager = new Manager(ref _list);
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        MainWindow = new MainWindow()
        {
            DataContext = new MainViewModel(_manager)
        };
        MainWindow.Show();

        base.OnStartup(e);
    }
}
