﻿using ClassLibrary;
using Generator.Models;
using Generator.ViewModels;
using Microsoft.Win32;
using System.IO;

namespace Generator.Commands;

public class ReadCsvCommand : CommandBase
{
    private SourcesManagerViewModel _viewModel;
    private Mystructure _list;
    private Manager _manager;


    public ReadCsvCommand(SourcesManagerViewModel viewModel, Manager manager)
    {
        _viewModel = viewModel;
        _manager = manager;
        _list = manager.Structure;
    }

    public override void Execute(object? parameter)
    {
        var ofd = new OpenFileDialog();
        ofd.Filter = "CSV súbory (*.csv) | *.csv";
        ofd.ShowDialog();

        if (!ofd.FileName.Equals(""))
        {
            var csvFileName = new FileInfo(ofd.FileName);
            CSVData csvFile = new(csvFileName);
            csvFile.Fill();

            _manager.AddCSV(csvFile);

            _viewModel.PridajZdroj(5687943);
            
        }
    }
}
