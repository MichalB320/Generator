﻿using System.Windows.Controls;

namespace Generator.Views
{
    /// <summary>
    /// Interaction logic for SourcesManagerView.xaml
    /// </summary>
    public partial class SourcesManagerView : UserControl
    {
        public SourcesManagerView()
        {
            InitializeComponent();
        }
    }
}
