﻿using Generator.Models;

namespace Generator.ViewModels;

public class MainViewModel : ViewModelBase
{
    public ViewModelBase CurrentViewModel { get; }

    public MainViewModel(Manager manager)
    {
        CurrentViewModel = new SourcesManagerViewModel(manager);
    }
}
