﻿using ClassLibrary;
using Generator.ViewModels;
using System.Collections.ObjectModel;
using System.DirectoryServices;
using System.Text;

namespace Generator.Models;

public class Generator
{
    private string[][] _pole;
    private string _input;
    private List<string> _strings;
    private List<string> _variables;
    private List<string> _sources;

    private Mystructure _stlpce;

    private Mystructure _structure;
    private ObservableCollection<ButtonViewModel> _buttons;

    public Generator(string input, Mystructure structure, ObservableCollection<ButtonViewModel> buttons)
    {
        _input = input;
        _strings = new();
        _variables = new();
        _sources = new();
        _structure = structure;
        _buttons = buttons;

        _stlpce = new();
    }

    public string Generate()
    {
        string input = _input;
        int count = input.Count(c => c == '$');

        StringBuilder sb = new();
        for (int j = 0; j < _pole[0].Length; j++)
        {
            int startIndex1 = -1;
            for (int i = 0; i < count / 2; i++)
            {
                int startIndex = startIndex1;
                int endIndex = input.IndexOf('$', startIndex + 1);
                startIndex1 = input.IndexOf('$', endIndex + 1);
                string subStr = input.Substring(startIndex + 1, endIndex - 1 - startIndex);
                //output.Dispatcher.Invoke(() => output.AppendText($"{subStr}{resultEntry.InvokeGet(vars[i])}"));
                sb.Append($"{subStr}{_pole[i][j]}");//      resultEntry.InvokeGet(vars[i])
            }
            sb.Append("\n");
            sb.Append("\n");
        }
        return sb.ToString();
    }

    //useradd $csv.meno$ je v skupine $csv.skupina$ a jeho cislo je $uid$ to som ja.
    //"useradd -c \"$(cn=Michal*).displayName$\" -d /home/$(cn=Michal*).uid$ -u $(cn=Michal*).uidNumber$ -m -g $(cn=Michal*).gidNumber$ -s /bin/bash $(cn=Michal*).uid$\nchmod 701 /home/$(cn=Michal*).uid$";
    public void GenerateLine(int index)
    {
        string[] substrs = new string[]
        {
            "useradd -c ", " -d /home/", " -u ", " -m -g ", " -s /bin/bash ", "\nchmod 701 /home/"
        };

        string v1 = "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < _stlpce.Count; i++)
        {
            Type typ = _stlpce.GetTypeOf(i);
            if (typ != typeof(CSVData))
            {
                SearchResultCollection results = _stlpce.GetItem<SearchResultCollection>(i);
                foreach (SearchResult result in results)
                {
                    DirectoryEntry resultEntry = result.GetDirectoryEntry();
                    string propName = _variables[i];
                    v1 = (string)resultEntry.InvokeGet(propName);
                }
            }
            if (typ == typeof(CSVData))
            {
                int indexCsvStlpca = _stlpce.GetItem<CSVData>(i).GetRow(0).IndexOf(_variables[i]);
                v1 = _stlpce.GetItem<CSVData>(i).GetRow(index + 1)[indexCsvStlpca];//[stlpecCSV]
            }

            sb.Append(substrs[i] + "" + v1);
            //string output = jeden + v1 + dva;
        }
    }

    public void PrepareVariable()
    {

        Mystructure stlpce = new();

        _pole = new string[][]
        {
            new string[] { "michal", "maria", "jozko" },
            new string[] { "513", "514", "515"},
            new string[] { "559550", "559024", "559011"}
        };

        List<string> foundMatch = new List<string>();

        foreach (ButtonViewModel btnVM in _buttons)
        {
            if (_sources.Contains(btnVM.Content))
            {
                foundMatch.Add(btnVM.Content);
            }
        }



        int indexSource = 0;
        foreach (string source in _sources)
        {
            ButtonViewModel btn = _buttons.FirstOrDefault(BtnVM => BtnVM.Content == _sources[indexSource]);

            int index = _buttons.IndexOf(btn);

            if (_buttons[index].Type == typeof(CSVData))
            {
                CSVData csv = _structure.GetItem<CSVData>(index);
                stlpce.Add(csv);
            }
            if (_buttons[index].Type == typeof(SearchResultCollection))
            {
                SearchResultCollection ldap = _structure.GetItem<SearchResultCollection>(index);
                stlpce.Add(ldap);
            }
            indexSource++;
        }


        _stlpce = stlpce;

        Join();
    }

    public void FindStrings()
    {
        int startI = _input.IndexOf('$');
        int count = _input.Count(c => c == '$');

        for (int i = 0; i < count / 2; i++)
        {
            int startIndex = startI;
            int endIndex = _input.IndexOf('$', startIndex + 1);
            startI = _input.IndexOf('$', endIndex + 1);
            string subStr = _input.Substring(startIndex + 1, endIndex - 1 - startIndex);
            _strings.Add(subStr);
        }
    }

    public void FindSourcesAndVariables()
    {
        foreach (string str in _strings)
        {
            string[] parts = str.Split('.');
            _sources.Add(parts[0]);
            _variables.Add(parts[1]);
        }
    }

    public void Join(/*string keyA, string keyB*/)
    {
        //List<SearchResultCollection> LdapS = new();
        //List<CSVData> CsvS = new();

        //for (int i = 0; i < _structure.Count; i++)
        //{
        //    if (_structure.GetTypeOf(i) == typeof(CSVData))
        //    {
        //        CSVData subor = _structure.GetItem<CSVData>(i);
        //        CsvS.Add(subor);
        //    }
        //    else if (_structure.GetTypeOf(i) != typeof(CSVData))
        //    {
        //        SearchResultCollection results = _structure.GetItem<SearchResultCollection>(i);
        //        LdapS.Add(results);
        //    }
        //}

        List<string> join = new();
        string[][] matrix = new string[_stlpce.Count][];
        for (int i = 0; i < _stlpce.Count; i++)
        {
            matrix[i] = new string[24];
        }


        for (int i = 0; i < _stlpce.Count; i++)
        {
            for (int j = 0; j < 24; j++)
            {
                string v1 = "";
                StringBuilder sb = new StringBuilder();

                Type typ = _stlpce.GetTypeOf(i);
                if (typ != typeof(CSVData))
                {
                    SearchResultCollection results = _stlpce.GetItem<SearchResultCollection>(i);
                    //foreach (SearchResult result in results)
                    //{
                    //    DirectoryEntry resultEntry = result.GetDirectoryEntry();
                    //    string propName = _variables[i];
                    //    v1 = (string)resultEntry.InvokeGet(propName).ToString();
                    //}

                    SearchResult result = results[j];
                    DirectoryEntry resultEntry = result.GetDirectoryEntry();
                    string propName = _variables[i];

                    PropertyCollection properties = resultEntry.Properties;

                    if (properties.Contains(propName))
                    {
                        v1 = (string)resultEntry.InvokeGet(propName).ToString();
                    }
                    else
                    {
                        v1 = "";
                    }

                    //v1 = (string)resultEntry.InvokeGet(propName).ToString();

                    //v1 = "LDAP";
                }
                if (typ == typeof(CSVData))
                {
                    int indexCsvStlpca = _stlpce.GetItem<CSVData>(i).GetRow(0).IndexOf(_variables[i]);
                    v1 = _stlpce.GetItem<CSVData>(i).GetRow(j + 1)[indexCsvStlpca];//[stlpecCSV]
                }

                matrix[i][j] = v1;
            }
        }
        _pole = matrix;
    }
}
