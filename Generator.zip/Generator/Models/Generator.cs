﻿namespace Generator.Models
{
    internal class Generator
    {
    }
}
