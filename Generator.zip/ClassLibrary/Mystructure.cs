﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace ClassLibrary;

public class Mystructure : INotifyPropertyChanged
{
    private ObservableCollection<object> _list;
    public ObservableCollection<object> List
    {
        get { return _list; }
        set
        {
            if (_list != value)
            {
                _list = value;
                OnPropertyChanged(nameof(List));
                OnPropertyChanged(nameof(Count));
            }
        }
    }

    public int Count { get => _list.Count; }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public Mystructure()
    {
        _list = new();
    }

    public object this[int index]
    {
        get
        {
            if (index >= 0 && index < _list.Count)
                return _list[index];
            else
                throw new IndexOutOfRangeException("Index out of range exception.");
        }
        set
        {
            if (index >= 0 && index < _list.Count)
                _list[index] = value;
            else
                throw new IndexOutOfRangeException("Index out of range exception.");
        }
    }

    public void Add<T>(T item) => _list.Add(item);

    public void RemoveAt(int index) => _list.RemoveAt(index);
}
