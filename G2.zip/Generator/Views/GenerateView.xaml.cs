﻿using System.Windows.Controls;

namespace Generator.Views
{
    /// <summary>
    /// Interaction logic for GenerateView.xaml
    /// </summary>
    public partial class GenerateView : UserControl
    {
        public GenerateView()
        {
            InitializeComponent();
        }
    }
}
