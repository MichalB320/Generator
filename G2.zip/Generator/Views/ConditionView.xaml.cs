﻿using System.Windows.Controls;

namespace Generator.Views
{
    /// <summary>
    /// Interaction logic for ConditionView.xaml
    /// </summary>
    public partial class ConditionView : UserControl
    {
        public ConditionView()
        {
            InitializeComponent();
        }
    }
}
