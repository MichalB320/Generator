﻿using ClassLibrary;
using Generator.Commands;
using Generator.Models;
using System;
using System.Windows;
using System.Windows.Input;

namespace Generator.ViewModels;

public class SourcesManagerViewModel : ViewModelBase
{
    public int _count;
    public int Count
    {
        get => _count;
        set
        {
            _count = value;
            OnPropertyChanged(nameof(Count));
            //Application.Current.Dispatcher.Invoke(() =>
            //{
            //    OnPropertyChanged(nameof(Count));
            //});
        }
    }

    private string _query;
    public string Query
    {
        get { return _query; }
        set
        {
            _query = value;
            OnPropertyChanged(nameof(Query));
        }
    }

    private Mystructure _list;
    public Mystructure List
    {
        get { return _list; }
        set
        {
            if (_list != value)
            {
                _list = value;
                OnPropertyChanged(nameof(List));
                OnPropertyChanged(nameof(Count));
            }
        }
    }

    

    public ICommand CsvCommand { get; }
    public ICommand LdapCommand { get; }

    public SourcesManagerViewModel(Manager manager)
    {
        var list = manager.Structure;
        CsvCommand = new ReadCsvCommand(this, manager);
        _list = list;
        PridajZdroj(50);
    }

    public void PridajZdroj(int i)
    {
        Count = i;
        //OnPropertyChanged(nameof(Count));

        //Application.Current.Dispatcher.Invoke(() =>
        //{
        //    OnPropertyChanged(nameof(Count));
        //});
        
    }
}
