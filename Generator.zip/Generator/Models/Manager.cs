﻿using ClassLibrary;
using System.DirectoryServices;

namespace Generator.Models;

public class Manager
{
    private Mystructure _struct;
    public Mystructure Structure
    {
        get;
        set;
    }

    public Manager(ref Mystructure structure)
    {
        _struct = structure;
    }




    public void AddCSV(CSVData csvData) => _struct.Add<CSVData>(csvData);

    public void AddSearchResultCollection(SearchResultCollection ldapData) => _struct.Add<SearchResultCollection>(ldapData);
}
